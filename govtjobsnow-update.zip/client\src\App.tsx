import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { UserProvider } from "@/contexts/user-context";
import { PWAProvider } from "@/contexts/pwa-context";
import Home from "@/pages/home";
import JobDetail from "@/pages/job-detail";
import ExamCalendarPage from "@/pages/exam-calendar-page";
import AdminLogin from "@/pages/admin-login";
import AdminDashboard from "@/pages/admin-dashboard";
import Contact from "@/pages/contact";
import FAQ from "@/pages/faq";
import PrivacyPolicy from "@/pages/privacy-policy";
import TermsOfService from "@/pages/terms-of-service";
import Disclaimer from "@/pages/disclaimer";
import SSCJobs from "@/pages/ssc-jobs";
import RailwayJobs from "@/pages/railway-jobs";
import NotFound from "@/pages/not-found";
import AboutUs from "@/pages/about-us";
import CookieBanner from "@/components/cookie-banner";
import InstallPWA from "@/components/install-pwa";
import PWAManualGuide from "@/components/pwa-manual-guide";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/job/:id" component={JobDetail} />
      <Route path="/exams" component={ExamCalendarPage} />
      <Route path="/admin/login" component={AdminLogin} />
      <Route path="/admin/dashboard" component={AdminDashboard} />
      <Route path="/contact" component={Contact} />
      <Route path="/faq" component={FAQ} />
      <Route path="/privacy-policy" component={PrivacyPolicy} />
      <Route path="/terms-of-service" component={TermsOfService} />
      <Route path="/disclaimer" component={Disclaimer} />
      <Route path="/about-us" component={AboutUs} />
      <Route path="/jobs/ssc" component={SSCJobs} />
      <Route path="/jobs/railway" component={RailwayJobs} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <UserProvider>
        <PWAProvider>
          <TooltipProvider>
            <Toaster />
            <Router />
            <CookieBanner />
            <InstallPWA />
            <PWAManualGuide />
          </TooltipProvider>
        </PWAProvider>
      </UserProvider>
    </QueryClientProvider>
  );
}

export default App;
